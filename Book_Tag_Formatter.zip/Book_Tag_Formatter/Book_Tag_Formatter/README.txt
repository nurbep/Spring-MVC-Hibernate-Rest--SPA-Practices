This demo is for lesson: Lesson Spring MVC Tag Library

It uses XML file to demo.

It contains Map which demo form:select will use key as id. Need to uncomment it.


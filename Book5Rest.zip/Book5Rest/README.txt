Same as Book5a WITH

Restful Service with VALIDATION added VALIDATES ISBN
Add Category

Re-worked "data' into Repository [ still needs more work]  
Test of Forward from POST to GET ... 
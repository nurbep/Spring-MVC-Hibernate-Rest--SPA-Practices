This demo is for lesson: Spring & Spring MVC Frameworks

it demos:
1. request mapping
2. base configuration for spring mvc project(p50)
3. Matrix variables(p93). URL example: http://localhost:8080/webstore/market/products/filter/params;brands=Google,Dell;categories=Tablet,Laptop
4. RequestParam, PathVariable

The repository is inmemory repository,  connect to hsql database which use Spring JDBCTemplate.
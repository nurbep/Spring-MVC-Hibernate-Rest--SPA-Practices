
Look at Employee for Validation example 
Disallowed Fields example - need to uncomment ID in Binder

This demo is for lesson: Spring & Spring MVC Frameworks

it demos:
1. data binding
2. request mapping
3. base configuration for spring mvc project

The repository is inmemory repository, didn't connect to any database.
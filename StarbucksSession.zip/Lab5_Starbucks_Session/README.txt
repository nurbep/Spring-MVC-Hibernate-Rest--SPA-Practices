Demonstrates use of @SessionAttributes

Similar to Lab6_Starbucks THAT version does MAP of Roasts... THIS one does @SessionAttributes